package com.iiht.ecoronakit.enums;


public enum Category {

    Fashion("Fashion"), Grocery("Grocery"), Electronics("Electronics");

    private String category;

    Category(String category) {
        this.category = category;
    }
}
