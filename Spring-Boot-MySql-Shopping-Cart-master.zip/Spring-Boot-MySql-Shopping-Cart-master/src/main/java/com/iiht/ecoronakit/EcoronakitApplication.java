package com.iiht.ecoronakit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EcoronakitApplication {

	public static void main(String[] args) {
		SpringApplication.run(EcoronakitApplication.class, args);
	}
	

}
