package com.iiht.ecoronakit.service.serviceimpl;

import com.iiht.ecoronakit.models.UserCart;
import com.iiht.ecoronakit.service.UserCartService;

import java.util.List;


public class UserCartServiceImpl implements UserCartService {


    @Override
    public List<UserCart> addItem(List<UserCart> dtos) {
        return null;
    }

    @Override
    public UserCart updateItem(UserCart dto, Long cartId) {
        return null;
    }

    @Override
    public List<UserCart> findAll() {
        return null;
    }

    @Override
    public String deleteById(Long cartId) {
        return null;
    }
}
